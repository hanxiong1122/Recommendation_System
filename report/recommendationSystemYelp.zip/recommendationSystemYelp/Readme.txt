1. Open RecomSys.py or GuiPart.py to run the code
2. it may take a few minutes to obtain an effecive recommendation list. Be patient please, thanks