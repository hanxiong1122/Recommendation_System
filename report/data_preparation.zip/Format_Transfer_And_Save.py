# Written by Hanxiong Wang, Dong Shi and Yingjiao Liang on 11/1/2016
# Transfer the data format json into a easy-use form by python
import json
data_review = []
data_user = []
data_business = []

import pickle

with open('yelp_academic_dataset_review.json', 'r') as f:
   for line in f:
      data_review.append(json.loads(line))
f1 = open("data_review_overall.dat","wb")
pickle.dump(data_review,f1,True)
f1.close()

with open('yelp_academic_dataset_user.json','r') as f:
   for line in f:
      data_user.append(json.loads(line))
f2 = open("data_user_overall.dat","wb")
pickle.dump(data_user,f2,True)
f2.close()

with open('yelp_academic_dataset_business.json', 'r') as f:
   for line in f:
      data_business.append(json.loads(line))
f3 = open("data_business_overall.dat","wb")
pickle.dump(data_business,f3,True)
f3.close()

print('Done')
