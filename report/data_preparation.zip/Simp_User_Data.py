# Written by Hanxiong Wang, Dong Shi and Yingjiao Liang on 11/1/2016

import pickle
data_user = pickle.load(open("data_user_overall.dat",'rb'))
data_review_PA = pickle.load(open("data_review_PA.dat",'rb'))
print('Loading done')

# build a set to collect all user id
user_id = set()
for i in range(len(data_review_PA)):
    user_id.add(data_review_PA[i]["user_id"])
print('user_id',len(user_id))

# filter the user information by user id
i = 0
flag = 0
while flag == 0:
    if data_user[i]['user_id'] in user_id:
        i += 1
    else:
        data_user.pop(i)
    if i+1 > len(data_user):
        flag = 1
print('data_user', len(data_user))

# save the new user information
f = open("data_user_PA.dat","wb")
pickle.dump(data_user,f,True)
f.close()
