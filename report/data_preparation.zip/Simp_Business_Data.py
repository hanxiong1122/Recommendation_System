# Written by Hanxiong Wang, Dong Shi and Yingjiao Liang on 11/1/2016

import pickle
data_business = pickle.load(open("data_business_overall.dat",'rb'))

# check the distribution by State
StateDict = {}
for i in range(len(data_business)):
    if data_business[i]["state"] in StateDict:
       StateDict[data_business[i]["state"]] +=1
    else :
       StateDict[data_business[i]["state"]]=1
print('Statelist', StateDict)

# filter the state except PA
data_business2= data_business.copy()
i = 0
flag = 0
while flag ==0:
    if data_business2[i]["state"] == 'PA':
        i += 1
    else:
        data_business2.pop(i)
    if i+1>len(data_business2):
        flag = 1

# find how many restaurants in PA
StateDict2 = {}
for i in range(len(data_business2)):
    if data_business2[i]["state"] in StateDict2:
       StateDict2[data_business2[i]["state"]] +=1
    else :
       StateDict2[data_business2[i]["state"]]=1
print(StateDict2)

# save the new business information
f = open("data_business_PA.dat","wb")
pickle.dump(data_business2,f,True)
f.close()
