# Written by Hanxiong Wang, Dong Shi and Yingjiao Liang on 11/1/2016

import pickle
data_review = pickle.load(open("data_review_overall.dat",'rb'))
data_business_PA = pickle.load(open("data_business_PA.dat",'rb'))

print('Loading done')

# build a set to collect all the business id
business_id = set()
for i in range(len(data_business_PA)):
    business_id.add(data_business_PA[i]["business_id"])

# filter the review information by business id 
i = 0
counts = 1
flag = 0
while flag ==0:
    if data_review[i]["business_id"] in business_id:
        i += 1
    else:
        data_review.pop(i)
    if i+1>len(data_review):
        flag = 1
    counts += 1
    if  counts%5000 == 0:
        print(counts)

# save the new review information
f = open("data_review_PA.dat","wb")
pickle.dump(data_review,f ,True)
f.close()
